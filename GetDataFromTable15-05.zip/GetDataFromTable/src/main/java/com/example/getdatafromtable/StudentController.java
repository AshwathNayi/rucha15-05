package com.example.getdatafromtable;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class StudentController 
{
    @Autowired
   private StudentRepo srepo;
    @Autowired
   private JdbcTemplate t;
	
	@RequestMapping("/register")
   public String savedata(Model model,StudentModel sm) 
   {
		srepo.save(sm);
		return "Display";
	
   }
	@GetMapping("/register/report")
	@ResponseBody
	@CrossOrigin
	public List<Map<String,Object>> showdata(@RequestParam("tablename")String tblnm) 
	{
		String sql="select * from " + tblnm;
		System.out.println(sql);
		List<Map<String,Object>> data=t.queryForList(sql);
		return data;
	}
}
